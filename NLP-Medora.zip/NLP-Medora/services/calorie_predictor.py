import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

df = pd.read_csv("data/Dataset.csv")
features = ['weight(kg)', 'height(m)', 'BMR', 'activity_level']
target = 'calories_to_maintain_weight'

X = df[features].values
y = df[target].values.reshape(-1, 1)

scaler_X = StandardScaler()
scaler_y = StandardScaler()
X_scaled = scaler_X.fit_transform(X)
y_scaled = scaler_y.fit_transform(y)

X_train, X_test, y_train, y_test = train_test_split(X_scaled, y_scaled, test_size=0.2, random_state=42)

model = Sequential([
    Dense(128, activation='relu', input_shape=(X_train.shape[1],)),
    Dense(64, activation='relu'),
    Dense(32, activation='relu'),
    Dense(1, activation='linear')
])
model.compile(optimizer='adam', loss='mse', metrics=['mae'])
model.fit(X_train, y_train, epochs=80, batch_size=16, verbose=0)

weight_map = {1: 45, 2: 65, 3: 80, 4: 100}
height_map = {1: 1.55, 2: 1.70, 3: 1.85}
activity_map = {1: 1.2, 2: 1.375, 3: 1.55, 4: 1.725, 5: 1.9}

def predict_calories(weight_choice, height_choice, activity_choice, gender, age):
    weight = weight_map[weight_choice]
    height = height_map[height_choice]
    activity_level = activity_map[activity_choice]

    BMR = 10 * weight + 6.25 * (height * 100) - 5 * age + (5 if gender == "M" else -161)
    BMI = weight / (height ** 2)

    bmi_status = (
        "Oops! You are underweight." if BMI < 18.5 else
        "Good! You have normal weight." if BMI < 25 else
        "You are overweight." if BMI < 30 else
        "You are obese."
    )

    user_input = np.array([[weight, height, BMR, activity_level]])
    user_input_scaled = scaler_X.transform(user_input)
    predicted_scaled = model.predict(user_input_scaled)
    maintenance_calories = scaler_y.inverse_transform(predicted_scaled)[0][0]

    return {
        "BMI": round(BMI, 1),
        "bmi_status": bmi_status,
        "maintenance": round(maintenance_calories),
        "loss": round(maintenance_calories - 500),
        "gain": round(maintenance_calories + 500)
    }